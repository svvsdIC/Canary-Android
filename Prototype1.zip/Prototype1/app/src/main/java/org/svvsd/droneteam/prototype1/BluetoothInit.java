package org.svvsd.droneteam.prototype1;

/**
 * Created by tran.michel02 on 7/25/2017.
 */

public class BluetoothInit {
    // Research how to establish a connect between Xbee and phone
}
