package org.svvsd.droneteam.prototype1;

/**
 * Created by tran.michel02 on 7/25/2017.
 */
// Import Libraries
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

// So, just to be sure: This code creates the tools to store data in a table in a database on the
// phone, and then it uses the msg method to send off the data in String form. Then the msg will be
// manipulated in SendGCM, and then sent in that class as well.

// Our own personal database for the app will likely be an SQL database
public class DatabaseUtils extends SQLiteOpenHelper
{
    private static final String DATABASE_NAME = "App_Database.db";
    private static final int DATABASE_VERSION = 1;
    private static SQLiteDatabase db;

    DatabaseUtils(Context context) {

        // calls the super constructor, requesting the default cursor factory.
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        db = this.getWritableDatabase();
    }
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        // Check type of data sent in from sensors (I think double), and also ask Jim
        db.execSQL("CREATE TABLE IF NOT EXISTS Atmospheric_Data (psi TEXT, humidity TEXT, temp TEXT, gasVOC TEXT, barometric_psi TEXT, altitude TEXT, ambient_temp TEXT)");

    }

    // This should be automatic with changing version in member variables
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // upgrade database code here
    }

/* METHODS AFTER THIS MAY NOT BE RELEVANT IF WE ARE SENDING DATA VIA URL RATHER THAN TABLES */
    public Cursor selectFromTable(String sTable, String sColumn, String sWhere)
    {
//msg("selectFromTable select " + sColumn + " from " + sTable + " where " + sWhere);
        Cursor c = db.query(sTable, sColumn.split(","), sWhere, null, null, null, null);
        c.moveToFirst();
        return c;
    }

    public Cursor selectFromTableOrder(String sTable, String sColumn, String sWhere, String sOrder)
    {
//msg("selectFromTableOrder select " + sColumn + " from " + sTable + " where " + sWhere + " order by " + sOrder);
        Cursor c = db.query(sTable, sColumn.split(","), sWhere, null, null, null, sOrder);
        c.moveToFirst();
        return c;
    }

    public String getQueryResult(Cursor c, String sColumn, int iPosition)
    {
//msg("getQueryResult " + sColumn + " at row " + iPosition);
        String sReturn = "";
        if (c.getCount() > iPosition)
        {
            c.moveToPosition(iPosition);
            int iColumnIndex = c.getColumnIndex(sColumn);
            if (iColumnIndex > -1)
            {
                sReturn = c.getString(iColumnIndex);
                if (sReturn == null)
                {
                    sReturn = "";
                    //msg("getQueryResult is null");
                }
                else
                {
//msg("getQueryResult value is " + sReturn);
                }

            }
            else
            {
                // msg("getQueryResult error column not found");
            }
        }
        else
        {
            //msg("getQueryResult error " + sColumn + ", " + iPosition + ", count " + c.getCount());
        }

        return sReturn;
    }

    public int getQueryResultInt(Cursor c, String sColumn, int iPosition)
    {
        int iResult = 0;
        String sResult = getQueryResult(c, sColumn, iPosition);
        if (sResult.length() > 0)
        {
            iResult = Integer.parseInt(sResult);
        }

        return iResult;
    }

    public void replaceIntoTable(String sTable, String[] aColumns, String[] aValues)
    {
//msg("replaceIntoTable replace into " + sTable + " (" + TextUtils.join(",", aColumns) + ") values ('" + TextUtils.join("','", aValues) + ")");
        ContentValues nv = new ContentValues(aColumns.length);
        for (int i = 0; i < aColumns.length; i++)
        {
            nv.put(aColumns[i], aValues[i]);
        }
        db.replace(sTable, null, nv);

    }

    public void updateTable(String sTable, String sColumn, String sValue, String sWhere)
    {
        ContentValues nv = new ContentValues(1);
        nv.put(sColumn, sValue);

        db.update(sTable, nv, sWhere, null);
    }

    public int deleteFromTable(String sTable, String sWhere)
    {
        return db.delete(sTable, sWhere, null);
    }


    public void msg(String sMsg)
    {
        System.out.println("PWTW DBUtils: " + sMsg);

    }
}