package org.svvsd.droneteam.prototype1;

// All as Jim wrote it... change to accommodate for rest of project
import android.content.Context;
import android.os.AsyncTask;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;

public class SendGCM extends AsyncTask<String, Void, Boolean>
{
    private Context context;

    public SendGCM(Context contxt)
    {
        context = contxt;
    }

    protected Boolean doInBackground(String... aStrings)
    {
        String sTo = aStrings[0];
        String sMsg = aStrings[1];


        String sPost = "{\"priority\":\"high\",\"data\":{" + sMsg + "},\"registration_ids\":[\"" + sTo + "\"]}";
        msg("Posting " + sPost);
        Boolean bSuccess = true;
        try
        {
            // get authorization key
            String sAuth = "";
            URL url = new URL("https://android.googleapis.com/gcm/send"); // Find URL key for CHORDS
            HttpsURLConnection urlConnection = (HttpsURLConnection) url.openConnection();
            urlConnection.setRequestMethod("POST");
            urlConnection.setRequestProperty("Content-Type", "application/json");
            urlConnection.setRequestProperty("Authorization", "key=" + sAuth);
            urlConnection.setRequestProperty("Content-Length", String.valueOf(sPost.length()));
            urlConnection.setDoOutput(true);
            urlConnection.setChunkedStreamingMode(0);

            OutputStream out = new BufferedOutputStream(urlConnection.getOutputStream());
            out.write(sPost.getBytes());
            out.flush();

            InputStream in = new BufferedInputStream(urlConnection.getInputStream());
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            int i = in.read();
            while (i != -1) {
                bo.write(i);
                i = in.read();
            }
            String sResponse = bo.toString();

            urlConnection.disconnect();
            msg("Received " + sResponse);
            bSuccess = (sResponse.contains("\"failure\":0")); // a success
        }
        catch (Exception e)
        {
            e.printStackTrace();
            bSuccess = false;
        }

        return bSuccess;

    }
    protected void onPostExecute(Boolean bSuccess)
    {
        if (!bSuccess)
        {
            // NEED TO CREATE NotificationUtils CLASS!!!
            //.new NotificationUtils(context).screenMsg(context.getString(R.string.comm_problem));
        }
    }

    public void msg(String sMsg)
    {

        System.out.println("PWTW SENDGCM: " + sMsg);
    }
}
